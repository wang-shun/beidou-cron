<?PHP
    
    $BASE_DIR="/home/work/snapshot";
    
    $IMAGE_SERVER=array("host"=>"jx-veyron00.jx.baidu.com",
                        "user"=>"work",
                        "passwd"=>"beidourdfe518",
                        "path"=>"/home/work/beidou/snap_image");
                        
    $REPEAT_TIMEOUT=60;
    
    $ALLOW_IPS=array("127.0.0.1","10.65.5.218");
    
    ini_set('date.timezone','Asia/Shanghai');
                        
    set_time_limit(0)
    
?>
