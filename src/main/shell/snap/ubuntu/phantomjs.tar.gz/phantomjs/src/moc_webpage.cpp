/****************************************************************************
** Meta object code from reading C++ file 'webpage.h'
**
** Created: Tue Dec 18 15:44:22 2012
**      by: The Qt Meta Object Compiler version 62 (Qt 4.7.4)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "webpage.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'webpage.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 62
#error "This file was generated using the moc from 4.7.4. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_WebPage[] = {

 // content:
       5,       // revision
       0,       // classname
       0,    0, // classinfo
      18,   14, // methods
       6,  104, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       7,       // signalCount

 // signals: signature, parameters, type, tag, flags
       9,    8,    8,    8, 0x05,
      23,    8,    8,    8, 0x05,
      44,   37,    8,    8, 0x05,
      70,   66,    8,    8, 0x05,
     125,   99,    8,    8, 0x05,
     179,  175,    8,    8, 0x05,
     216,  207,    8,    8, 0x05,

 // slots: signature, parameters, type, tag, flags
     263,  243,    8,    8, 0x0a,
     301,    8,    8,    8, 0x0a,
     325,  320,  311,    8, 0x0a,
     357,  348,  343,    8, 0x0a,
     384,  373,  343,    8, 0x0a,
     412,  402,    8,    8, 0x0a,
     460,  442,    8,    8, 0x0a,
     503,  488,    8,    8, 0x0a,
     550,  540,    8,    8, 0x2a,
     583,  578,    8,    8, 0x2a,
     605,  602,    8,    8, 0x08,

 // properties: name, type, flags
     626,  618, 0x0a095103,
     634,  618, 0x0a095103,
     658,  646, 0x08095103,
     671,  646, 0x08095103,
     681,  646, 0x08095103,
     690,  646, 0x08095103,

       0        // eod
};

static const char qt_meta_stringdata_WebPage[] = {
    "WebPage\0\0initialized()\0loadStarted()\0"
    "status\0loadFinished(QString)\0msg\0"
    "javaScriptAlertSent(QString)\0"
    "message,lineNumber,source\0"
    "javaScriptConsoleMessageSent(QString,int,QString)\0"
    "req\0resourceRequested(QVariant)\0"
    "resource\0resourceReceived(QVariant)\0"
    "address,op,settings\0"
    "openUrl(QString,QVariant,QVariantMap)\0"
    "release()\0QVariant\0code\0evaluate(QString)\0"
    "bool\0fileName\0render(QString)\0jsFilePath\0"
    "injectJs(QString)\0scriptUrl\0"
    "_appendScriptElement(QString)\0"
    "selector,fileName\0uploadFile(QString,QString)\0"
    "type,arg1,arg2\0sendEvent(QString,QVariant,QVariant)\0"
    "type,arg1\0sendEvent(QString,QVariant)\0"
    "type\0sendEvent(QString)\0ok\0finish(bool)\0"
    "QString\0content\0libraryPath\0QVariantMap\0"
    "viewportSize\0paperSize\0clipRect\0"
    "scrollPosition\0"
};

const QMetaObject WebPage::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_WebPage,
      qt_meta_data_WebPage, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &WebPage::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *WebPage::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *WebPage::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_WebPage))
        return static_cast<void*>(const_cast< WebPage*>(this));
    return QObject::qt_metacast(_clname);
}

int WebPage::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: initialized(); break;
        case 1: loadStarted(); break;
        case 2: loadFinished((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 3: javaScriptAlertSent((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 4: javaScriptConsoleMessageSent((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< const QString(*)>(_a[3]))); break;
        case 5: resourceRequested((*reinterpret_cast< const QVariant(*)>(_a[1]))); break;
        case 6: resourceReceived((*reinterpret_cast< const QVariant(*)>(_a[1]))); break;
        case 7: openUrl((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< const QVariant(*)>(_a[2])),(*reinterpret_cast< const QVariantMap(*)>(_a[3]))); break;
        case 8: release(); break;
        case 9: { QVariant _r = evaluate((*reinterpret_cast< const QString(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< QVariant*>(_a[0]) = _r; }  break;
        case 10: { bool _r = render((*reinterpret_cast< const QString(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 11: { bool _r = injectJs((*reinterpret_cast< const QString(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 12: _appendScriptElement((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 13: uploadFile((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< const QString(*)>(_a[2]))); break;
        case 14: sendEvent((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< const QVariant(*)>(_a[2])),(*reinterpret_cast< const QVariant(*)>(_a[3]))); break;
        case 15: sendEvent((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< const QVariant(*)>(_a[2]))); break;
        case 16: sendEvent((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 17: finish((*reinterpret_cast< bool(*)>(_a[1]))); break;
        default: ;
        }
        _id -= 18;
    }
#ifndef QT_NO_PROPERTIES
      else if (_c == QMetaObject::ReadProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< QString*>(_v) = content(); break;
        case 1: *reinterpret_cast< QString*>(_v) = libraryPath(); break;
        case 2: *reinterpret_cast< QVariantMap*>(_v) = viewportSize(); break;
        case 3: *reinterpret_cast< QVariantMap*>(_v) = paperSize(); break;
        case 4: *reinterpret_cast< QVariantMap*>(_v) = clipRect(); break;
        case 5: *reinterpret_cast< QVariantMap*>(_v) = scrollPosition(); break;
        }
        _id -= 6;
    } else if (_c == QMetaObject::WriteProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: setContent(*reinterpret_cast< QString*>(_v)); break;
        case 1: setLibraryPath(*reinterpret_cast< QString*>(_v)); break;
        case 2: setViewportSize(*reinterpret_cast< QVariantMap*>(_v)); break;
        case 3: setPaperSize(*reinterpret_cast< QVariantMap*>(_v)); break;
        case 4: setClipRect(*reinterpret_cast< QVariantMap*>(_v)); break;
        case 5: setScrollPosition(*reinterpret_cast< QVariantMap*>(_v)); break;
        }
        _id -= 6;
    } else if (_c == QMetaObject::ResetProperty) {
        _id -= 6;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 6;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 6;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 6;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 6;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 6;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}

// SIGNAL 0
void WebPage::initialized()
{
    QMetaObject::activate(this, &staticMetaObject, 0, 0);
}

// SIGNAL 1
void WebPage::loadStarted()
{
    QMetaObject::activate(this, &staticMetaObject, 1, 0);
}

// SIGNAL 2
void WebPage::loadFinished(const QString & _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void WebPage::javaScriptAlertSent(const QString & _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}

// SIGNAL 4
void WebPage::javaScriptConsoleMessageSent(const QString & _t1, int _t2, const QString & _t3)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)), const_cast<void*>(reinterpret_cast<const void*>(&_t3)) };
    QMetaObject::activate(this, &staticMetaObject, 4, _a);
}

// SIGNAL 5
void WebPage::resourceRequested(const QVariant & _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 5, _a);
}

// SIGNAL 6
void WebPage::resourceReceived(const QVariant & _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 6, _a);
}
QT_END_MOC_NAMESPACE
