/****************************************************************************
** Meta object code from reading C++ file 'phantom.h'
**
** Created: Tue Dec 18 15:44:20 2012
**      by: The Qt Meta Object Compiler version 62 (Qt 4.7.4)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "phantom.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'phantom.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 62
#error "This file was generated using the moc from 4.7.4. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_Phantom[] = {

 // content:
       5,       // revision
       0,       // classname
       0,    0, // classinfo
      11,   14, // methods
       6,   69, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      18,    8,    9,    8, 0x0a,
      34,    8,    9,    8, 0x0a,
      52,    8,    9,    8, 0x0a,
      84,   79,   71,    8, 0x0a,
     126,  115,  110,    8, 0x0a,
     149,  144,    8,    8, 0x0a,
     159,    8,    8,    8, 0x2a,
     166,  144,    8,    8, 0x0a,
     181,    8,    8,    8, 0x2a,
     215,  193,    8,    8, 0x08,
     256,    8,    8,    8, 0x08,

 // properties: name, type, flags
     284,  272, 0x0b095001,
     301,  289, 0x08095001,
     321,   71, 0x0a095103,
     333,   71, 0x0a095103,
     348,   71, 0x0a095001,
     359,  289, 0x08095001,

       0        // eod
};

static const char qt_meta_stringdata_Phantom[] = {
    "Phantom\0\0QObject*\0createWebPage()\0"
    "createWebServer()\0createFilesystem()\0"
    "QString\0name\0loadModuleSource(QString)\0"
    "bool\0jsFilePath\0injectJs(QString)\0"
    "code\0exit(int)\0exit()\0debugExit(int)\0"
    "debugExit()\0msg,lineNumber,source\0"
    "printConsoleMessage(QString,int,QString)\0"
    "onInitialized()\0QStringList\0args\0"
    "QVariantMap\0defaultPageSettings\0"
    "libraryPath\0outputEncoding\0scriptName\0"
    "version\0"
};

const QMetaObject Phantom::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_Phantom,
      qt_meta_data_Phantom, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &Phantom::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *Phantom::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *Phantom::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_Phantom))
        return static_cast<void*>(const_cast< Phantom*>(this));
    return QObject::qt_metacast(_clname);
}

int Phantom::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: { QObject* _r = createWebPage();
            if (_a[0]) *reinterpret_cast< QObject**>(_a[0]) = _r; }  break;
        case 1: { QObject* _r = createWebServer();
            if (_a[0]) *reinterpret_cast< QObject**>(_a[0]) = _r; }  break;
        case 2: { QObject* _r = createFilesystem();
            if (_a[0]) *reinterpret_cast< QObject**>(_a[0]) = _r; }  break;
        case 3: { QString _r = loadModuleSource((*reinterpret_cast< const QString(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = _r; }  break;
        case 4: { bool _r = injectJs((*reinterpret_cast< const QString(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 5: exit((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 6: exit(); break;
        case 7: debugExit((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 8: debugExit(); break;
        case 9: printConsoleMessage((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< const QString(*)>(_a[3]))); break;
        case 10: onInitialized(); break;
        default: ;
        }
        _id -= 11;
    }
#ifndef QT_NO_PROPERTIES
      else if (_c == QMetaObject::ReadProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< QStringList*>(_v) = args(); break;
        case 1: *reinterpret_cast< QVariantMap*>(_v) = defaultPageSettings(); break;
        case 2: *reinterpret_cast< QString*>(_v) = libraryPath(); break;
        case 3: *reinterpret_cast< QString*>(_v) = outputEncoding(); break;
        case 4: *reinterpret_cast< QString*>(_v) = scriptName(); break;
        case 5: *reinterpret_cast< QVariantMap*>(_v) = version(); break;
        }
        _id -= 6;
    } else if (_c == QMetaObject::WriteProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 2: setLibraryPath(*reinterpret_cast< QString*>(_v)); break;
        case 3: setOutputEncoding(*reinterpret_cast< QString*>(_v)); break;
        }
        _id -= 6;
    } else if (_c == QMetaObject::ResetProperty) {
        _id -= 6;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 6;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 6;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 6;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 6;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 6;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}
QT_END_MOC_NAMESPACE
