/****************************************************************************
** Meta object code from reading C++ file 'webserver.h'
**
** Created: Tue Dec 18 15:44:22 2012
**      by: The Qt Meta Object Compiler version 62 (Qt 4.7.4)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "webserver.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'webserver.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 62
#error "This file was generated using the moc from 4.7.4. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_WebServer[] = {

 // content:
       5,       // revision
       0,       // classname
       0,    0, // classinfo
       5,   14, // methods
       1,   39, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: signature, parameters, type, tag, flags
      28,   11,   10,   10, 0x05,

 // slots: signature, parameters, type, tag, flags
      68,   63,   58,   10, 0x0a,
      98,   10,   90,   10, 0x0a,
     105,   10,   10,   10, 0x0a,
     140,  113,   10,   10, 0x08,

 // properties: name, type, flags
      63,   90, 0x0a095001,

       0        // eod
};

static const char qt_meta_stringdata_WebServer[] = {
    "WebServer\0\0request,response\0"
    "newRequest(QVariant,QObject*)\0bool\0"
    "port\0listenOnPort(QString)\0QString\0"
    "port()\0close()\0event,conn,request,handled\0"
    "handleRequest(mg_event,mg_connection*,const mg_request_info*,bool*)\0"
};

const QMetaObject WebServer::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_WebServer,
      qt_meta_data_WebServer, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &WebServer::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *WebServer::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *WebServer::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_WebServer))
        return static_cast<void*>(const_cast< WebServer*>(this));
    return QObject::qt_metacast(_clname);
}

int WebServer::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: newRequest((*reinterpret_cast< QVariant(*)>(_a[1])),(*reinterpret_cast< QObject*(*)>(_a[2]))); break;
        case 1: { bool _r = listenOnPort((*reinterpret_cast< const QString(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 2: { QString _r = port();
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = _r; }  break;
        case 3: close(); break;
        case 4: handleRequest((*reinterpret_cast< mg_event(*)>(_a[1])),(*reinterpret_cast< mg_connection*(*)>(_a[2])),(*reinterpret_cast< const mg_request_info*(*)>(_a[3])),(*reinterpret_cast< bool*(*)>(_a[4]))); break;
        default: ;
        }
        _id -= 5;
    }
#ifndef QT_NO_PROPERTIES
      else if (_c == QMetaObject::ReadProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< QString*>(_v) = port(); break;
        }
        _id -= 1;
    } else if (_c == QMetaObject::WriteProperty) {
        _id -= 1;
    } else if (_c == QMetaObject::ResetProperty) {
        _id -= 1;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 1;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 1;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 1;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 1;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 1;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}

// SIGNAL 0
void WebServer::newRequest(QVariant _t1, QObject * _t2)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}
static const uint qt_meta_data_WebServerResponse[] = {

 // content:
       5,       // revision
       0,       // classname
       0,    0, // classinfo
       8,   14, // methods
       2,   54, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      38,   19,   18,   18, 0x0a,
      70,   65,   18,   18, 0x0a,
      89,   18,   85,   18, 0x0a,
     107,  102,   18,   18, 0x0a,
     139,  134,  126,   18, 0x0a,
     166,  155,   18,   18, 0x0a,
     205,   18,  193,   18, 0x0a,
     223,  215,   18,   18, 0x0a,

 // properties: name, type, flags
     247,   85, 0x02095103,
     215,  193, 0x08095103,

       0        // eod
};

static const char qt_meta_stringdata_WebServerResponse[] = {
    "WebServerResponse\0\0statusCode,headers\0"
    "writeHead(int,QVariantMap)\0data\0"
    "write(QString)\0int\0statusCode()\0code\0"
    "setStatusCode(int)\0QString\0name\0"
    "header(QString)\0name,value\0"
    "setHeader(QString,QString)\0QVariantMap\0"
    "headers()\0headers\0setHeaders(QVariantMap)\0"
    "statusCode\0"
};

const QMetaObject WebServerResponse::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_WebServerResponse,
      qt_meta_data_WebServerResponse, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &WebServerResponse::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *WebServerResponse::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *WebServerResponse::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_WebServerResponse))
        return static_cast<void*>(const_cast< WebServerResponse*>(this));
    return QObject::qt_metacast(_clname);
}

int WebServerResponse::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: writeHead((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< const QVariantMap(*)>(_a[2]))); break;
        case 1: write((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 2: { int _r = statusCode();
            if (_a[0]) *reinterpret_cast< int*>(_a[0]) = _r; }  break;
        case 3: setStatusCode((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 4: { QString _r = header((*reinterpret_cast< const QString(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = _r; }  break;
        case 5: setHeader((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< const QString(*)>(_a[2]))); break;
        case 6: { QVariantMap _r = headers();
            if (_a[0]) *reinterpret_cast< QVariantMap*>(_a[0]) = _r; }  break;
        case 7: setHeaders((*reinterpret_cast< const QVariantMap(*)>(_a[1]))); break;
        default: ;
        }
        _id -= 8;
    }
#ifndef QT_NO_PROPERTIES
      else if (_c == QMetaObject::ReadProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< int*>(_v) = statusCode(); break;
        case 1: *reinterpret_cast< QVariantMap*>(_v) = headers(); break;
        }
        _id -= 2;
    } else if (_c == QMetaObject::WriteProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: setStatusCode(*reinterpret_cast< int*>(_v)); break;
        case 1: setHeaders(*reinterpret_cast< QVariantMap*>(_v)); break;
        }
        _id -= 2;
    } else if (_c == QMetaObject::ResetProperty) {
        _id -= 2;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 2;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 2;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 2;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 2;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 2;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}
QT_END_MOC_NAMESPACE
